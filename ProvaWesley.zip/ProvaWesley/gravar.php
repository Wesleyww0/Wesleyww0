<?php

// funções 

function Somar($numero1, $numero2){
     ($resultado = $numero1 + $numero2);
     return $resultado;
}

function Subitrair($numero1, $numero2){
     ($resultado = $numero1 - $numero2);
     return $resultado;
}

function Multiplicar($numero1, $numero2){
     ($resultado = $numero1 * $numero2);
     return $resultado;
}

function Dividir($numero1, $numero2){
     ($resultado = $numero1 / $numero2);
     return $resultado;
}

function seNegativo ($resultado){

    
    if($resultado<0){
        echo " é um numero negativo!!" ;
    }
}

function limpa($documento){
    return str_replace(['.', '=', ',', '+', '_', '*', '&', '%', '$', '*', '(', ')', '@', '!', '¨', '#', '~', ':', ';'], '', $documento); // escolhi não validade espaço para poder cadastrar varias Anas ( ana lucia, ana clara, ana maria), e também dar espaço a profissões com nome composto ( Analista de sistemas, Engenheiro civil).
}




//rand para criar arquivos json diferentes aleatorios ( porém acredito que sobrescreve, vou descobrir como resolver)
$controle = rand(1,555);

// validando se esta escrito ou vazio
$numero1 = (isset($_POST['numero1'])) ? $_POST ['numero1'] : '' ;
$numero2 = (isset($_POST['numero2'])) ? $_POST ['numero2'] : '' ;
$operacao = (isset($_POST['operacao'])) ? $_POST ['operacao'] : '' ;




    
    

// limpando os campos de caracteres especiais
$numero1Limpo = limpa($numero1);
$numero2Limpo = limpa($numero2);


// gerando mensagens de erro com if

$msgErro = '';

    if (empty($numero1Limpo) || empty($numero2Limpo) ) {
        $numero1Limpo = 0;
        $numero2Limpo = 0;
        echo '- Existem campos de numeros não preenchidos para o calculo <BR>';
    }

    //  if da operação

    $resultado = 0;

    if ($operacao == "Soma"){
        echo $resultado = Somar($numero1Limpo, $numero2Limpo);        
    }elseif ($operacao == "Subtração"){
        echo $resultado = Subitrair($numero1Limpo, $numero2Limpo);
    }elseif ($operacao == "Multiplicação"){
        echo $resultado = Multiplicar($numero1Limpo, $numero2Limpo);
    }elseif ($operacao == "Divisão"){
        echo $resultado = Dividir($numero1Limpo, $numero2Limpo);

    }   

    
    // se negativo

    //$resultadofinal = seNegativo($resultado);

    if($resultado<0){
        echo " é um numero negativo!!" ;
    }

   


    // resultado

    
// array das variaveis
$json = [
    'numero1'=>$numero1Limpo,
    'numero2'=>$numero2Limpo, 
    'operacao'=>$operacao,
    'resultado'=>$resultado
];


//definindo o arquivo resultante, abrindo o recurso
$fh = fopen("arquivo/Dados$controle.json", 'w');

//salvando o arquivo com json_encode
// definindo oque vai estar no arquivo .json
fwrite($fh, json_encode($json, JSON_UNESCAPED_UNICODE));


// fechando o recurso
fclose($fh);

header('Refresh: 5; listar.php'); // pesquisei hoje

?>


