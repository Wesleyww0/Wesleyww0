<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Calcular</title>
</head>

<body>

    <nav>
        <a href="listar.php">Lista de calculos</a>

    </nav>
    <br>
    <hr>

    <h1>Calcule</h1>

    <form action="gravar.php" method="post">
        <label>Número 1</label>
        <input type="number" name="numero1" id="numero1" ><br><br><br> <!-- coloquei required para os campos serem obrigatorios -->
        <label>Número 2</label>
        <input type="number" name="numero2" id="numero2" ><br><br><br>
        <select name="operacao" id="operacao">
            <option value="Soma">Soma</option>
            <option value="Subtração">Subtração</option>
            <option value="Multiplicação">Multiplicação</option>
            <option value="Divisão">Divisão</option>
        </select>
        <button>Calcular</button>
        

    </form>

</body>

</html>