<?php 

    $arquivo_recebido = $_GET ['file'];


    $arquivo = './arquivo/' . $arquivo_recebido;


    //1- abrir o arquivo em memória (recurso)
    $recurso = fopen($arquivo, 'r');

    //2- Leitura do arquivo
    $json = fread($recurso, filesize($arquivo));

    //3- Fechar o recurso (evitar o consumo de memória)
    fclose($recurso);

    /* forma de objeto*/
    $dados = json_decode($json , true);
    
    // var_dump($dados);

    foreach ($dados as $json) {
        echo $json  . PHP_EOL;
    }
    
    //echo 'numero1: ' . $dados -> numero1 . '<br>';
    //echo 'numero2: ' . $dados -> numero2 . '<br>';
    //echo 'operacao'. $dados -> operacao .'<br>';
    //echo 'resultado'. $dados -> resultado .'<br>';

    // header('Location: /listar.php');
    
    // Forma de array associativo (basta adicionar o 'true'  no json decode) 
    
    // echo 'Nome: ' . $dados['nome'] . '<br>';

    ?>